#requires -Version 7.2
param([ValidateSet('baseline','candidate')][string]$Stage,[ValidateSet('host','194','188')][string]$Lane)
$ErrorActionPreference='Stop'
$taskRepo=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
Set-Location $taskRepo
$taskOutput=Join-Path $taskRepo "target/projection-groups-checks/$Stage"
if(-not(Test-Path $taskOutput)){New-Item -ItemType Directory -Path $taskOutput -Force|Out-Null}
$taskSteps=@();$taskFailure=$null
function Record([string]$Name,[scriptblock]$Call){
    $taskLog=Join-Path $taskOutput "$Lane-$Name.log"
    if(Test-Path $taskLog){throw 'Never replace check evidence'}
    & $Call *> $taskLog
    $taskCode=[int]$LASTEXITCODE
    $script:taskSteps+=@{name=$Name;exit=$taskCode;log=[IO.Path]::GetFileName($taskLog);sha256=(Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant()}
    if($taskCode -ne 0){throw "Check failed: $Stage/$Lane/$Name ($taskCode)"}
}
try{
    if($Lane -ceq 'host'){
        $taskTests=@('--test','pidfd_info_path_074','--test','held_material_live_074','--test','held_material_074','--test','held_unit_projection_074','--test','boot_operations_074','--test','held_preparation_cost_074')
        if($Stage -ceq 'candidate'){$taskTests+=@('--test','projection_groups_074')}
        Record 'canaries' { & cargo test --offline --locked -p xtask @taskTests }
        Record 'check' { & cargo check --offline --locked -p xtask -p hydracache-long-run-supervisor-074 --all-targets }
        Record 'clippy' { & cargo clippy --offline --locked -p xtask -p hydracache-long-run-supervisor-074 --all-targets --all-features -- -D warnings }
    }else{
        $taskCompiler=if($Lane -ceq '194'){'+1.94.0'}else{'+1.88.0'}
        $taskTarget="CARGO_TARGET_DIR=/home/artur/.cache/hydracache-074-$Lane-check"
        Record 'allocations' { & wsl.exe -d Ubuntu -u artur -- env RUSTUP_AUTO_INSTALL=0 $taskTarget /home/artur/.cargo/bin/cargo $taskCompiler test --offline --locked --release --features fixed-leaf-alloc-probe -p hydracache-long-run-supervisor-074 --lib projection_groups -- --nocapture --test-threads=1 }
        if($Stage -ceq 'candidate'){
            foreach($taskFilter in @('projection_groups','kernel_projection','consuming_join')){
                Record $taskFilter { & wsl.exe -d Ubuntu -u artur -- env RUSTUP_AUTO_INSTALL=0 $taskTarget /home/artur/.cargo/bin/cargo $taskCompiler test --offline --locked --release -p hydracache-long-run-supervisor-074 --lib $taskFilter -- --nocapture --test-threads=1 }
            }
        }
        Record 'check' { & wsl.exe -d Ubuntu -u artur -- env RUSTUP_AUTO_INSTALL=0 $taskTarget /home/artur/.cargo/bin/cargo $taskCompiler check --offline --locked -p hydracache-long-run-supervisor-074 --all-targets }
        Record 'clippy' { & wsl.exe -d Ubuntu -u artur -- env RUSTUP_AUTO_INSTALL=0 $taskTarget /home/artur/.cargo/bin/cargo $taskCompiler clippy --offline --locked -p hydracache-long-run-supervisor-074 --all-targets --all-features -- -D warnings }
    }
}catch{$taskFailure=$_.Exception.Message}
@{stage=$Stage;lane=$Lane;steps=$taskSteps;failure=$taskFailure;ignored_tests_run=$false;original_owner_profiles=0;server=$false;product=$false}|ConvertTo-Json -Depth 8|Out-File (Join-Path $taskOutput "$Lane-result.json") -Encoding utf8 -NoClobber
if($taskFailure){throw $taskFailure}
